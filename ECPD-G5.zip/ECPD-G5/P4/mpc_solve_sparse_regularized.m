function [u0, exitflag] = mpc_solve_sparse(x0, H, R, A, B, C, lb, ub, y_max_inc,const_type)
% MPC_SOLVE_SPARSE  Sparse formulation of the MPC tracker (quadprog).
%
% Supports box constraints on the H control moves and an upper bound
% on the (incremental) output. The output bound can be hard
% (const_type = 0) or relaxed with a non-negative slack variable eta
% that is quadratically penalised in the cost (const_type = 1).
%
% Inputs
%   x0          current (incremental) state            (n x 1)
%   H           prediction horizon                     (scalar)
%   R           input weight                           (scalar)
%   A, B, C     incremental state-space matrices
%   lb, ub      bounds on the control sequence U       (H x 1, optional)
%   y_max_inc   upper bound on the incremental output  (scalar, optional)
%   const_type  0 -> hard output constraint (default)
%               1 -> soft  output constraint with slack eta
%
% Outputs
%   u0          first move of the optimal sequence (receding horizon)
%   exitflag    quadprog exit status
%
%--------------------------------------------------------------------------

if nargin < 7,  lb        = []; end
if nargin < 8,  ub        = []; end
if nargin < 9,  y_max_inc = []; end
if nargin < 10,  const_type = 0; end % use hard by default 

use_output_constraint = ~isempty(y_max_inc);

%% Dimensions
n   = size(A, 1);
N_x = (H+1) * n;        % stacked states (x_0 ... x_H)
N_u = H;                % control moves over the horizon
N_eta = N_u;            % one slack per predicted output -- for y(i) 1x1
N_z = N_x + N_u;        % decision vector in hard mode
N_z_soft = N_z + N_eta; % decision vector when slacks are added

%% Cost  --  F = 2*blkdiag(Qtilde, Rtilde) + epsilon*I
Q_stage = C' * C;
Qtilde  = blkdiag(zeros(n), kron(eye(H), Q_stage));
Rtilde  = R * eye(H);
epsilon = 1e-6;

alpha= 50;  % slack penalty -- only when const_type == 1

F = 2 * blkdiag(Qtilde + epsilon*eye((H+1)*n), Rtilde);
f = zeros(N_z, 1);

% Soft mode: extend the cost so the slack vector eta becomes part of the
% decision vector and is penalised with alpha.
if const_type == 1
    F = blkdiag(F, alpha * eye(N_eta));
    f = [f; zeros(N_eta,1)];
end

%% Equality constraints: dynamics + initial condition
N_eq = (H+1) * n;
Aeq  = zeros(N_eq, N_z);
beq  = zeros(N_eq, 1);

% Initial condition: xhat(0) = x0
Aeq(1:n, 1:n) = eye(n);
beq(1:n)      = x0;

% Dynamics: xhat(ii+1) - A*xhat(ii) - B*uhat(ii) = 0
for ii = 0:H-1
    r1 = n + ii*n + 1;
    r2 = n + (ii+1)*n;
    Aeq(r1:r2, (ii+1)*n+1:(ii+2)*n) =  eye(n);   % +I on xhat(ii+1)
    Aeq(r1:r2,     ii*n+1:(ii+1)*n) = -A;         % -A on xhat(ii)
    Aeq(r1:r2,            N_x+ii+1) = -B;         % -B on uhat(ii)
end

% In soft mode the slacks do not enter the dynamics, so the equality
% block is just padded with zero columns. The RHS is left alone.
if const_type == 1
    Aeq = [Aeq, zeros(N_eq, N_eta)];
end

%% Control bounds
if const_type==0
    if ~isempty(lb) || ~isempty(ub)
        if isempty(lb), lb = -inf(N_u, 1); end
        if isempty(ub), ub =  inf(N_u, 1); end
        lb_z = [-inf(N_x, 1); lb];
        ub_z = [ inf(N_x, 1); ub];
    else
        lb_z = [];
        ub_z = [];
    end
end 
if const_type==1 % soft mode -- also include the eta bounds
    if ~isempty(lb) || ~isempty(ub)
        if isempty(lb), lb = -inf(N_u, 1); end
        if isempty(ub), ub =  inf(N_u, 1); end
        lb_z = [-inf(N_x, 1); lb; ones(N_eta,1)*0.0001];% eta >=0
        ub_z = [ inf(N_x, 1); ub; inf(N_eta,1)]; 
    else
        lb_z = [];
        ub_z = [];
    end
end


%% Output constraint: yhat(i) <= y_max_inc, i = 1,...,H
if use_output_constraint
    if const_type==0 % hard
        C_til  = [zeros(H, n), kron(eye(H), C)];
        A_ineq = [C_til, zeros(H, N_u)];
        b_ineq = y_max_inc * ones(H, 1);
    end
    if const_type==1 % soft -- the slack relaxes the bound
        C_til  = [zeros(H, n), kron(eye(H), C)];
        A_ineq = [C_til, zeros(H, N_u), -eye(N_eta)];% include slack column
        b_ineq = y_max_inc * ones(H, 1);
    end
else
    A_ineq = [];
    b_ineq = [];
       
end

%% Solve
opts = optimoptions('quadprog',           ...
    'Algorithm',           'interior-point-convex', ...
    'OptimalityTolerance', 1e-9,          ...
    'ConstraintTolerance', 1e-9,          ...
    'StepTolerance',       1e-12,         ...
    'Display',             'off');

[U_opt, ~, exitflag] = quadprog(F, f, A_ineq, b_ineq, Aeq, beq, lb_z, ub_z, [], opts);

%% Receding horizon: return first control action
u0 = U_opt(N_x + 1);

end